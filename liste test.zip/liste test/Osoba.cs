﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace liste_test
{
    //Napraviti klasu osoba unutar koje se deklariraju atributi: ime, prezime, datum rođenja i matični broj. 
    internal class Osoba
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public DateTime DatumRođenja { get; set; }
        public int MatičniBroj { get; set; }


    }
}
