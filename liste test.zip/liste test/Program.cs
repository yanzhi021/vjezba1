﻿namespace liste_test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<OD> od = new List<OD>();

        }
    }
}