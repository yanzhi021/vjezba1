﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace liste_test
{
    //Klasa Osiguranik nasljeđuje klasu osoba i dodatno sadrži atribute:
    //Iznos uplate za osiguranje, datum kada je osoba prvi put osigurana,
  
    internal class Osiguranik:Osoba
    {
        List<Osoba> osoba = new List<Osoba>();
        public double Uplata { get; set; }
        public DateTime PrviPutOsigurana { get; set; }
        public Osiguranik()
        {
            Console.WriteLine("Unesite iznos uplate za osiguranje: ");
            Uplata = int.Parse(Console.ReadLine());
            Console.WriteLine("Unesite datum kada je osoba prvi put osigurana: ");
            PrviPutOsigurana = DateTime.Parse(Console.ReadLine());
        }
        //metodu koja vraća nagradu osiguravajućeg društva u iznosu od 5% iznosa
        //ako je osiguranik klijent duže od 10 godina
        public void VraćaNagradu()
        {
            if (DateTime.Now.Year - PrviPutOsigurana.Year > 10)
                Uplata = Uplata * 0.95;
        
        }
        public void Ispis()
        {

        }

    


    }
}
