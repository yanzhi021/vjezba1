﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace liste_test
{
    //Napraviti klasu OD (Osiguravajuće društvo) koja sadrži:
    //Naziv društva, Adresu, te Listu osiguranika u tom društvu.
    //(Unutar konstruktora klase OD unositi broj osiguranika (n),
    //napraviti novih n osiguranika, te ih spremati u listu) 
    internal class OD
    {
        string NazivDruštva;
        int Adresa;
        List<Osiguranik> osiguranici = new List<Osiguranik>();
        public OD()
        {
            Console.WriteLine("Unesite naziv društva: ");
            NazivDruštva = Console.ReadLine();
            Console.WriteLine("Unesite adresu: ");
            Adresa = int.Parse(Console.ReadLine());

        }
            
       
        // a) metodu za unos novog osiguranika
        // b) brisanje osiguranika sa matičnim brojem kojeg unese korisnik
        // c) metoda koja vraća iznos osiguranika s najmanje uplaćenih novaca
        // d) metodu koja ispisuje ukupnu sumu nagrada koje OD mora isplatiti svim osiguranicima
        // e) Metodu koja ispisuje naziv OD-a, zatim sve informacije o klijentima

        //a
        public void NoviOsiguranik()
        {
            string ime, prezime;
            int Matičnibroj;
            DateTime DatumRođenja, PrviPutOsiguranja;
            double Uplata;

            Osiguranik o = new Osiguranik();

            Console.WriteLine("Unesite ime novog osiguranika: ");
            o.Ime = Console.ReadLine();
            Console.WriteLine("Unesite prezime novog osiguranika: ");
            o.Prezime = Console.ReadLine();
            Console.WriteLine("Unesite matični broj novog osiguranika: ");
            o.MatičniBroj = int.Parse(Console.ReadLine());
            Console.WriteLine("Unesite datum rođenja novog osiguranika: ");
            o.DatumRođenja = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Unesite datum prvog puta osiguranja novog osiguranika: ");
            o.PrviPutOsigurana = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Unesite iznos uplata novog osiguranika: ");
            o.Uplata = double.Parse(Console.ReadLine());


            osiguranici.Add(o);
        }

        //c
        public void NajmanjeUplaćenNovac()
        {
            Osiguranik min;
            min = osiguranici[0];
            foreach(Osiguranik o in osiguranici)
            {
                if (o.Uplata<min.Uplata)
                {
                    min=o;
                }
               
           
            }
            min.Ispis();
           
        }
        
        //b
        public void BrisanjeOsiguranika()
        {
            int MatričniBroj
            Console.WriteLine("Unesite matični broj osiguranika kojeg želite izbrisati: ");
            MatričniBroj = int.Parse(Console.ReadLine());
            foreach(Osiguranik o in osiguranik)
            {
                if(o.MatičniBroj=>MatičniBroj)
                {

                }
            }

        }

    }
}
